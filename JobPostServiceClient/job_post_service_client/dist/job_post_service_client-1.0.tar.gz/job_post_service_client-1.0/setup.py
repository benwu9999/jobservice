from distutils.core import setup

setup(
    name='job_post_service_client',
    version='1.0',
)